"use strict";
(() => {
  // src/content/redaction.ts
  var SENSITIVE_AUTOCOMPLETE = /* @__PURE__ */ new Set([
    "current-password",
    "new-password",
    "one-time-code",
    "cc-number",
    "cc-csc",
    "cc-exp",
    "cc-exp-month",
    "cc-exp-year"
  ]);
  var SENSITIVE_NAME_PATTERN = /pass(word)?|pwd|otp|one.?time|cvv|cvc|card.?(num|number)|ccnum|secret|token|ssn|social.?security|ein|ccv|pin\b/i;
  function isSensitiveField(el) {
    const type = "type" in el ? el.type : "";
    if (type === "password" || type === "hidden") return true;
    const autocomplete = el.autocomplete?.toLowerCase() ?? "";
    if (SENSITIVE_AUTOCOMPLETE.has(autocomplete)) return true;
    const nameLike = `${el.name} ${el.id}`;
    if (SENSITIVE_NAME_PATTERN.test(nameLike)) return true;
    return false;
  }
  function describeField(el) {
    return {
      tag: el.tagName.toLowerCase(),
      type: "type" in el ? el.type || "text" : "select",
      name: el.name || el.id || null
    };
  }

  // src/content/content.ts
  var paused = false;
  function send(event) {
    if (paused) return;
    const message = { kind: "CONTENT_EVENT", event };
    chrome.runtime.sendMessage(message).catch(() => {
    });
  }
  function nowIso() {
    return (/* @__PURE__ */ new Date()).toISOString();
  }
  function pageTitle() {
    return document.title || null;
  }
  function currentUrl() {
    return location.href;
  }
  function buildSelector(el) {
    if (el.id) return `#${el.id}`;
    const tag = el.tagName.toLowerCase();
    const parent = el.parentElement;
    if (!parent) return tag;
    const siblings = Array.from(parent.children).filter((c) => c.tagName === el.tagName);
    const index = siblings.indexOf(el) + 1;
    return `${tag}:nth-of-type(${index})`;
  }
  function safeLabel(el) {
    const aria = el.getAttribute("aria-label");
    if (aria) return aria.slice(0, 200);
    const text = el.innerText?.trim();
    if (text) return text.slice(0, 200);
    return void 0;
  }
  document.addEventListener(
    "click",
    (e) => {
      const target = e.target;
      if (!target) return;
      send({
        surface: "web",
        timestamp: nowIso(),
        eventType: "click",
        url: currentUrl(),
        pageTitle: pageTitle(),
        screenId: null,
        element: {
          tag: target.tagName.toLowerCase(),
          label: safeLabel(target),
          selector: buildSelector(target)
        },
        metadata: {}
      });
    },
    { capture: true }
  );
  function isFieldLike(el) {
    return el instanceof HTMLInputElement || el instanceof HTMLTextAreaElement;
  }
  document.addEventListener(
    "focusin",
    (e) => {
      if (!isFieldLike(e.target) || isSensitiveField(e.target)) return;
      const field = describeField(e.target);
      send({
        surface: "web",
        timestamp: nowIso(),
        eventType: "input_started",
        url: currentUrl(),
        pageTitle: pageTitle(),
        screenId: null,
        element: { tag: field.tag, label: field.name ?? void 0 },
        metadata: { fieldType: field.type }
      });
    },
    true
  );
  document.addEventListener(
    "focusout",
    (e) => {
      if (!isFieldLike(e.target) || isSensitiveField(e.target)) return;
      const field = describeField(e.target);
      send({
        surface: "web",
        timestamp: nowIso(),
        eventType: "input_completed",
        url: currentUrl(),
        pageTitle: pageTitle(),
        screenId: null,
        element: { tag: field.tag, label: field.name ?? void 0 },
        metadata: { fieldType: field.type }
      });
    },
    true
  );
  document.addEventListener(
    "change",
    (e) => {
      if (!(e.target instanceof HTMLSelectElement)) return;
      const field = describeField(e.target);
      send({
        surface: "web",
        timestamp: nowIso(),
        eventType: "select_changed",
        url: currentUrl(),
        pageTitle: pageTitle(),
        screenId: null,
        element: { tag: field.tag, label: field.name ?? void 0 },
        metadata: {}
      });
    },
    true
  );
  document.addEventListener(
    "submit",
    (e) => {
      const form = e.target;
      send({
        surface: "web",
        timestamp: nowIso(),
        eventType: "form_submit",
        url: currentUrl(),
        pageTitle: pageTitle(),
        screenId: null,
        element: form ? { tag: "form", selector: buildSelector(form) } : null,
        metadata: {}
      });
    },
    true
  );
  document.addEventListener(
    "invalid",
    (e) => {
      const field = e.target;
      send({
        surface: "web",
        timestamp: nowIso(),
        eventType: "validation_error",
        url: currentUrl(),
        pageTitle: pageTitle(),
        screenId: null,
        element: field ? { tag: field.tagName.toLowerCase() } : null,
        metadata: {}
      });
    },
    true
  );
  var lastScrollBucket = -1;
  var scrollTicking = false;
  function computeScrollBucket() {
    const doc = document.documentElement;
    const scrollable = doc.scrollHeight - doc.clientHeight;
    if (scrollable <= 0) return 0;
    const pct = window.scrollY / scrollable * 100;
    return Math.min(100, Math.max(0, Math.round(pct / 25) * 25));
  }
  window.addEventListener("scroll", () => {
    if (scrollTicking) return;
    scrollTicking = true;
    requestAnimationFrame(() => {
      const bucket = computeScrollBucket();
      if (bucket !== lastScrollBucket) {
        lastScrollBucket = bucket;
        send({
          surface: "web",
          timestamp: nowIso(),
          eventType: "scroll_bucket",
          url: currentUrl(),
          pageTitle: pageTitle(),
          screenId: null,
          element: null,
          metadata: { bucket }
        });
      }
      scrollTicking = false;
    });
  });
  chrome.runtime.onMessage.addListener(
    (message, _sender, sendResponse) => {
      if (message.kind === "GET_SELECTION") {
        const text = window.getSelection()?.toString().trim() ?? "";
        const response = { text, url: currentUrl(), title: pageTitle() ?? "" };
        sendResponse(response);
        return;
      }
      if (message.kind === "SET_PAUSED") {
        paused = message.paused;
        sendResponse({ ok: true });
      }
    }
  );
})();
