"use strict";
(() => {
  // ../../packages/domain/src/coverage.ts
  var COVERAGE_CATEGORIES = [
    "company_overview",
    "product_features",
    "pricing",
    "enterprise",
    "onboarding",
    "core_workflow",
    "integrations",
    "documentation",
    "settings",
    "mobile_experience"
  ];

  // ../../node_modules/tldts-core/dist/es6/src/options.js
  function setDefaultsImpl({ allowIcannDomains = true, allowPrivateDomains = false, detectIp = true, extractHostname: extractHostname2 = true, mixedInputs = true, validHosts = null, validateHostname = true }) {
    return {
      allowIcannDomains,
      allowPrivateDomains,
      detectIp,
      extractHostname: extractHostname2,
      mixedInputs,
      validHosts,
      validateHostname
    };
  }
  var DEFAULT_OPTIONS = (
    /*@__INLINE__*/
    setDefaultsImpl({})
  );

  // ../../node_modules/tldts-core/dist/es6/src/factory.js
  function getEmptyResult() {
    return {
      domain: null,
      domainWithoutSuffix: null,
      hostname: null,
      isIcann: null,
      isIp: null,
      isPrivate: null,
      publicSuffix: null,
      subdomain: null
    };
  }

  // ../../node_modules/tldts/dist/es6/index.js
  var RESULT = getEmptyResult();

  // ../../packages/domain/src/site.ts
  var LOCATION_EVENT_TYPES = [
    "page_view",
    "navigation",
    "back_navigation",
    "forward_navigation",
    "tab_changed"
  ];
  var LOCATION_EVENT_SET = new Set(LOCATION_EVENT_TYPES);

  // src/config.ts
  var API_BASE = "https://reconlens-henna.vercel.app";

  // src/sidepanel/sidepanel.ts
  var root = document.getElementById("app-root");
  var recordingBadge = document.getElementById("recording-badge");
  var pausedBadge = document.getElementById("paused-badge");
  var toastEl = document.getElementById("toast");
  var state = null;
  var auth = null;
  var showStartForm = false;
  var projectsCache = [];
  var activeForm = "none";
  var timerInterval;
  function send(message) {
    return chrome.runtime.sendMessage(message);
  }
  function showToast(message, isError = false) {
    toastEl.textContent = message;
    toastEl.classList.remove("hidden");
    toastEl.classList.toggle("error", isError);
    window.setTimeout(() => toastEl.classList.add("hidden"), 4e3);
  }
  function el(tag, attrs = {}, children = []) {
    const node = document.createElement(tag);
    for (const [k, v] of Object.entries(attrs)) node.setAttribute(k, v);
    for (const child of children) node.append(child);
    return node;
  }
  function formatDuration(ms) {
    const totalSeconds = Math.floor(ms / 1e3);
    const mm = Math.floor(totalSeconds / 60).toString().padStart(2, "0");
    const ss = (totalSeconds % 60).toString().padStart(2, "0");
    return `${mm}:${ss}`;
  }
  function elapsedMs(s) {
    if (!s.startedAt) return 0;
    const start = new Date(s.startedAt).getTime();
    const pausedNow = s.pausedAt ? Date.now() - new Date(s.pausedAt).getTime() : 0;
    return Math.max(0, Date.now() - start - s.pausedAccumMs - pausedNow);
  }
  async function refreshState() {
    [state, auth] = await Promise.all([
      send({ kind: "GET_STATE" }),
      send({ kind: "GET_AUTH" })
    ]);
    render();
  }
  chrome.runtime.onMessage.addListener((message) => {
    if (message.kind === "STATE_UPDATE") {
      state = message.state;
      render();
    } else if (message.kind === "AUTH_UPDATE") {
      auth = message.auth;
      projectsCache = [];
      render();
    }
  });
  function createScreenshotDropZone(onExtracted) {
    let imageDataUrl = null;
    const zone = el("div", { class: "drop-zone", tabindex: "0" }, ["Drag a screenshot here, paste, or click to choose a file"]);
    const fileInput = el("input", { type: "file", accept: "image/*", class: "hidden" });
    async function handleFile(file) {
      if (!file.type.startsWith("image/")) {
        showToast("Only image files are supported", true);
        return;
      }
      const reader = new FileReader();
      reader.onload = async () => {
        imageDataUrl = reader.result;
        zone.textContent = "";
        zone.classList.add("drop-zone-filled");
        const img = el("img", { src: imageDataUrl, class: "drop-zone-preview" });
        const status = el("span", { class: "drop-zone-status" }, ["Extracting text\u2026"]);
        zone.append(img, status);
        const result = await send({
          kind: "DESCRIBE_SCREENSHOT",
          imageDataUrl
        }).catch(() => ({ error: "Failed to analyze screenshot" }));
        if (result.error || !result.claim) {
          status.textContent = "Couldn't auto-read this image \u2014 fill in the details manually.";
        } else {
          status.textContent = "Extracted \u2014 review below before saving.";
          onExtracted({ claim: result.claim, extractedText: result.extractedText ?? "" });
        }
      };
      reader.readAsDataURL(file);
    }
    zone.addEventListener("click", () => fileInput.click());
    fileInput.addEventListener("change", () => {
      if (fileInput.files?.[0]) void handleFile(fileInput.files[0]);
    });
    zone.addEventListener("dragover", (e) => {
      e.preventDefault();
      zone.classList.add("drop-zone-active");
    });
    zone.addEventListener("dragleave", () => zone.classList.remove("drop-zone-active"));
    zone.addEventListener("drop", (e) => {
      e.preventDefault();
      zone.classList.remove("drop-zone-active");
      const file = e.dataTransfer?.files?.[0];
      if (file) void handleFile(file);
    });
    zone.addEventListener("paste", (e) => {
      const item = Array.from(e.clipboardData?.items ?? []).find((i) => i.type.startsWith("image/"));
      const file = item?.getAsFile();
      if (file) void handleFile(file);
    });
    const wrapper = el("div", { class: "field" }, [zone, fileInput]);
    return { element: wrapper, getImageDataUrl: () => imageDataUrl };
  }
  var CATEGORY_KEYWORDS = [
    ["pricing", /pricing|plans?|cost/i],
    ["onboarding", /onboarding|get(ting)?-?started|sign-?up|welcome/i],
    ["integrations", /integrations?|marketplace|connect|apps?\//i],
    ["documentation", /docs?|documentation|help|support|guide/i],
    ["settings", /settings|preferences|account/i],
    ["enterprise", /enterprise|business|teams?/i],
    ["mobile_experience", /mobile|ios|android/i],
    ["company_overview", /about|company|careers|team\b/i],
    ["product_features", /features?|product\b/i]
  ];
  function suggestCategory(url, title) {
    const haystack = `${url ?? ""} ${title ?? ""}`;
    for (const [category, pattern] of CATEGORY_KEYWORDS) {
      if (pattern.test(haystack)) return category;
    }
    return void 0;
  }
  function categoryOptions(selected) {
    const select = el("select", { id: "category-select" });
    select.append(el("option", { value: "" }, ["No category"]));
    for (const cat of COVERAGE_CATEGORIES) {
      const opt = el("option", { value: cat }, [cat.replace(/_/g, " ")]);
      if (cat === selected) opt.setAttribute("selected", "true");
      select.append(opt);
    }
    return select;
  }
  async function renderNotStarted() {
    root.innerHTML = "";
    root.append(el("h2", {}, ["Start a research session"]));
    root.append(el("p", { class: "subtitle" }, ["Competitive research, captured as you browse."]));
    if (projectsCache.length === 0) {
      projectsCache = (await send({ kind: "GET_PROJECTS" }).catch(
        () => ({ projects: [] })
      )).projects ?? [];
    }
    const projectField = el("div", { class: "field" });
    projectField.append(el("label", { for: "project-select" }, ["Project"]));
    const projectSelect = el("select", { id: "project-select" });
    if (projectsCache.length === 0) {
      projectSelect.append(el("option", { value: "" }, ["No projects yet \u2014 create one below"]));
    }
    for (const p of projectsCache) {
      projectSelect.append(el("option", { value: p.id }, [p.name]));
    }
    projectField.append(projectSelect);
    root.append(projectField);
    const newProjectDetails = el("details", {});
    newProjectDetails.append(el("summary", {}, ["+ New project"]));
    const nameInput = el("input", { id: "new-project-name", placeholder: "Company / Product name" });
    const companyInput = el("input", { id: "new-project-company", placeholder: "Company name (optional)" });
    const questionInput = el("textarea", {
      id: "new-project-question",
      rows: "2",
      placeholder: "What are you trying to learn? (optional)"
    });
    newProjectDetails.append(
      el("div", { class: "field" }, [nameInput]),
      el("div", { class: "field" }, [companyInput]),
      el("div", { class: "field" }, [questionInput])
    );
    root.append(newProjectDetails);
    const objectiveField = el("div", { class: "field" });
    objectiveField.append(el("label", { for: "objective" }, ["Research objective"]));
    const objectiveInput = el("textarea", {
      id: "objective",
      rows: "3",
      placeholder: "Understand pricing, onboarding, positioning and core workflow"
    });
    objectiveField.append(objectiveInput);
    root.append(objectiveField);
    const errorText = el("p", { class: "error-text hidden", id: "start-error" });
    root.append(errorText);
    const startBtn = el("button", { class: "primary" }, ["Start Research"]);
    startBtn.addEventListener("click", async () => {
      errorText.classList.add("hidden");
      startBtn.setAttribute("disabled", "true");
      try {
        let projectId = projectSelect.value;
        const newName = nameInput.value.trim();
        if (!projectId && newName) {
          const result2 = await send({
            kind: "CREATE_PROJECT",
            name: newName,
            companyName: companyInput.value.trim() || void 0,
            researchQuestion: questionInput.value.trim() || void 0
          });
          if (!result2.project) throw new Error(result2.error ?? "Failed to create project");
          projectId = result2.project.id;
        }
        if (!projectId) throw new Error("Select or create a project first");
        const granted = await chrome.permissions.request({ origins: ["<all_urls>"] });
        if (!granted) throw new Error("Browsing permission is required to capture your research");
        const sessionName = `${newName || "Research"} \u2014 ${(/* @__PURE__ */ new Date()).toLocaleDateString()}`;
        const result = await send({
          kind: "START_SESSION",
          projectId,
          sessionName,
          objective: objectiveInput.value.trim() || void 0
        });
        if (result.lastError) throw new Error(result.lastError);
        showStartForm = false;
        state = result;
        render();
      } catch (err) {
        errorText.textContent = err instanceof Error ? err.message : "Failed to start session";
        errorText.classList.remove("hidden");
      } finally {
        startBtn.removeAttribute("disabled");
      }
    });
    root.append(startBtn);
  }
  function renderRecording(s) {
    root.innerHTML = "";
    root.append(el("h2", {}, [s.session?.sessionName ?? "Research in progress"]));
    const timerEl = el("p", { class: "subtitle", id: "timer" }, [formatDuration(elapsedMs(s))]);
    root.append(timerEl);
    window.clearInterval(timerInterval);
    timerInterval = window.setInterval(() => {
      if (state) timerEl.textContent = formatDuration(elapsedMs(state));
    }, 1e3);
    const stats = el("div", { class: "stats-grid" });
    const statDefs = [
      ["Pages visited", s.counts.pagesVisited],
      ["Interactions", s.counts.interactions],
      ["Evidence", s.counts.evidence],
      ["Insights", s.counts.insights]
    ];
    for (const [label, value] of statDefs) {
      stats.append(
        el("div", { class: "stat" }, [
          el("span", { class: "value" }, [String(value)]),
          el("span", { class: "label" }, [label])
        ])
      );
    }
    root.append(stats);
    root.append(
      el("div", { class: "current-page" }, [
        `CURRENT SITE \xB7 ${s.sitesVisited.length} VISITED`,
        el("strong", {}, [s.currentSite ?? "\u2014"])
      ])
    );
    root.append(
      el("div", { class: "current-page" }, [
        "CURRENT PAGE",
        el("strong", {}, [s.currentPageTitle ?? s.currentPageUrl ?? "\u2014"])
      ])
    );
    if (activeForm === "none") {
      const actions = el("div", { class: "action-list" });
      const captureBtn = el("button", {}, ["Capture Evidence"]);
      captureBtn.addEventListener("click", () => {
        activeForm = "evidence";
        render();
      });
      const insightBtn = el("button", {}, ["Mark Insight"]);
      insightBtn.addEventListener("click", () => {
        activeForm = "insight";
        render();
      });
      const noteBtn = el("button", {}, ["Add Note"]);
      noteBtn.addEventListener("click", () => {
        activeForm = "note";
        render();
      });
      actions.append(captureBtn, insightBtn, noteBtn);
      root.append(actions);
      const controlRow = el("div", { class: "row" });
      if (s.status === "recording") {
        const pauseBtn = el("button", {}, ["Pause"]);
        pauseBtn.addEventListener("click", async () => {
          state = await send({ kind: "PAUSE_SESSION" });
          render();
        });
        controlRow.append(pauseBtn);
      } else {
        const resumeBtn = el("button", { class: "primary" }, ["Resume"]);
        resumeBtn.addEventListener("click", async () => {
          state = await send({ kind: "RESUME_SESSION" });
          render();
        });
        controlRow.append(resumeBtn);
      }
      const endBtn = el("button", { class: "danger" }, ["End Research"]);
      endBtn.addEventListener("click", async () => {
        endBtn.setAttribute("disabled", "true");
        state = await send({ kind: "END_SESSION" });
        render();
      });
      controlRow.append(endBtn);
      root.append(controlRow);
    } else if (activeForm === "evidence") {
      renderEvidenceForm();
    } else if (activeForm === "insight") {
      renderInsightForm();
    } else if (activeForm === "note") {
      renderNoteForm();
    }
  }
  async function renderEvidenceForm() {
    root.innerHTML = "";
    root.append(el("h2", {}, ["Capture Evidence"]));
    const selection = await send({ kind: "GET_CURRENT_SELECTION" }).catch(() => null);
    const claimInput = el("textarea", { id: "claim", rows: "2" });
    let extractedText = "";
    const dropZone = createScreenshotDropZone((result) => {
      claimInput.value = result.claim;
      extractedText = result.extractedText;
    });
    root.append(dropZone.element);
    if (selection?.text) {
      extractedText = selection.text;
      root.append(el("label", {}, ["Selected on page"]));
      root.append(el("div", { class: "evidence-preview" }, [`"${selection.text.slice(0, 400)}"`]));
    }
    const claimField = el("div", { class: "field" });
    claimField.append(el("label", { for: "claim" }, ["Claim / What does this mean?"]));
    claimField.append(claimInput);
    root.append(claimField);
    const contextField = el("div", { class: "field" });
    contextField.append(el("label", { for: "context" }, ["Why is this useful? (optional)"]));
    const contextInput = el("textarea", { id: "context", rows: "2" });
    contextField.append(contextInput);
    root.append(contextField);
    const categoryField = el("div", { class: "field" });
    categoryField.append(el("label", { for: "category-select" }, ["Category"]));
    const categorySelect = categoryOptions(suggestCategory(state?.currentPageUrl ?? null, state?.currentPageTitle ?? null));
    categoryField.append(categorySelect);
    root.append(categoryField);
    const screenshotField = el("div", { class: "field" });
    const screenshotCheckbox = el("input", { type: "checkbox", id: "with-screenshot" });
    const screenshotLabel = el("label", { for: "with-screenshot" }, [" Also capture a screenshot of the current tab"]);
    screenshotField.append(screenshotCheckbox, screenshotLabel);
    root.append(screenshotField);
    const row = el("div", { class: "row" });
    const cancelBtn = el("button", {}, ["Cancel"]);
    cancelBtn.addEventListener("click", () => {
      activeForm = "none";
      render();
    });
    const saveBtn = el("button", { class: "primary" }, ["Save Evidence"]);
    saveBtn.addEventListener("click", async () => {
      if (!claimInput.value.trim()) {
        showToast("Add a claim, or drop a screenshot to auto-fill one", true);
        return;
      }
      saveBtn.setAttribute("disabled", "true");
      const result = await send({
        kind: "CAPTURE_EVIDENCE",
        claim: claimInput.value.trim(),
        context: contextInput.value.trim() || void 0,
        category: categorySelect.value || void 0,
        capturedText: extractedText || void 0,
        withScreenshot: screenshotCheckbox.checked,
        droppedScreenshotDataUrl: dropZone.getImageDataUrl() ?? void 0
      });
      if (result.error) {
        showToast(result.error, true);
        saveBtn.removeAttribute("disabled");
        return;
      }
      activeForm = "none";
      showToast("Evidence saved");
      await refreshState();
    });
    row.append(cancelBtn, saveBtn);
    root.append(row);
  }
  function renderInsightForm() {
    root.innerHTML = "";
    root.append(el("h2", {}, ["Mark Insight"]));
    const noteInput = el("textarea", { id: "insight-note", rows: "3" });
    const dropZone = createScreenshotDropZone((result) => {
      noteInput.value = result.claim;
    });
    root.append(dropZone.element);
    const noteField = el("div", { class: "field" });
    noteField.append(el("label", { for: "insight-note" }, ["What caught your attention?"]));
    noteField.append(noteInput);
    root.append(noteField);
    const categoryField = el("div", { class: "field" });
    categoryField.append(el("label", { for: "category-select" }, ["Category"]));
    const categorySelect = categoryOptions(suggestCategory(state?.currentPageUrl ?? null, state?.currentPageTitle ?? null));
    categoryField.append(categorySelect);
    root.append(categoryField);
    const row = el("div", { class: "row" });
    const cancelBtn = el("button", {}, ["Cancel"]);
    cancelBtn.addEventListener("click", () => {
      activeForm = "none";
      render();
    });
    const saveBtn = el("button", { class: "primary" }, ["Save"]);
    saveBtn.addEventListener("click", async () => {
      if (!noteInput.value.trim()) {
        showToast("Write a note, or drop a screenshot to auto-fill one", true);
        return;
      }
      saveBtn.setAttribute("disabled", "true");
      const droppedScreenshotDataUrl = dropZone.getImageDataUrl() ?? void 0;
      const result = await send({
        kind: "MARK_INSIGHT",
        note: noteInput.value.trim(),
        category: categorySelect.value || void 0,
        withScreenshot: !droppedScreenshotDataUrl,
        droppedScreenshotDataUrl
      });
      if (result.error) {
        showToast(result.error, true);
        saveBtn.removeAttribute("disabled");
        return;
      }
      activeForm = "none";
      showToast("Insight saved");
      await refreshState();
    });
    row.append(cancelBtn, saveBtn);
    root.append(row);
  }
  function renderNoteForm() {
    root.innerHTML = "";
    root.append(el("h2", {}, ["Add Note"]));
    const noteInput = el("textarea", { id: "quick-note", rows: "3" });
    const dropZone = createScreenshotDropZone((result) => {
      noteInput.value = result.claim;
    });
    root.append(dropZone.element);
    const noteField = el("div", { class: "field" });
    noteField.append(el("label", { for: "quick-note" }, ["Note"]));
    noteField.append(noteInput);
    root.append(noteField);
    const row = el("div", { class: "row" });
    const cancelBtn = el("button", {}, ["Cancel"]);
    cancelBtn.addEventListener("click", () => {
      activeForm = "none";
      render();
    });
    const saveBtn = el("button", { class: "primary" }, ["Save"]);
    saveBtn.addEventListener("click", async () => {
      if (!noteInput.value.trim()) {
        showToast("Write something, or drop a screenshot to auto-fill it", true);
        return;
      }
      saveBtn.setAttribute("disabled", "true");
      const result = await send({
        kind: "MARK_INSIGHT",
        note: noteInput.value.trim(),
        withScreenshot: false,
        droppedScreenshotDataUrl: dropZone.getImageDataUrl() ?? void 0
      });
      if (result.error) {
        showToast(result.error, true);
        saveBtn.removeAttribute("disabled");
        return;
      }
      activeForm = "none";
      showToast("Note saved");
      await refreshState();
    });
    row.append(cancelBtn, saveBtn);
    root.append(row);
  }
  var processingRetryTimer;
  function renderProcessing() {
    root.innerHTML = "";
    root.append(el("p", { class: "center-note" }, ["Processing your research\u2026"]));
    window.clearTimeout(processingRetryTimer);
    processingRetryTimer = window.setTimeout(() => {
      if (state?.status !== "processing") return;
      const note = el("p", { class: "center-note" }, ["Still working on it? This is taking longer than expected."]);
      const retryBtn = el("button", { class: "primary" }, ["Retry ending session"]);
      retryBtn.addEventListener("click", async () => {
        retryBtn.setAttribute("disabled", "true");
        state = await send({ kind: "END_SESSION" });
        render();
      });
      root.append(note, retryBtn);
    }, 8e3);
  }
  var CSAT_LABELS = ["Poor", "Fair", "Okay", "Good", "Great"];
  var csatAnsweredFor = null;
  function renderCsat() {
    const box = el("div", { class: "current-page" });
    const sessionId = state?.session?.id ?? null;
    if (sessionId !== null && csatAnsweredFor === sessionId) {
      box.append(el("strong", {}, ["Thanks for the feedback!"]));
      return box;
    }
    box.append("HOW WAS THIS RECORDING?");
    const row = el("div", { class: "stats-grid" });
    for (const [i, label] of CSAT_LABELS.entries()) {
      const rating = i + 1;
      const btn = el("button", { title: label }, [String(rating)]);
      btn.addEventListener("click", async () => {
        row.querySelectorAll("button").forEach((b) => b.setAttribute("disabled", "true"));
        const result = await send({ kind: "SUBMIT_CSAT", rating });
        if (result.error) {
          showToast(result.error, true);
          row.querySelectorAll("button").forEach((b) => b.removeAttribute("disabled"));
          return;
        }
        csatAnsweredFor = sessionId;
        render();
      });
      row.append(btn);
    }
    box.append(row, el("span", { class: "label" }, ["1 = poor, 5 = great"]));
    return box;
  }
  function renderCompleted(s) {
    root.innerHTML = "";
    root.append(el("h2", {}, ["Session complete"]));
    const stats = el("div", { class: "stats-grid" });
    const statDefs = [
      ["Pages visited", s.counts.pagesVisited],
      ["Interactions", s.counts.interactions],
      ["Evidence", s.counts.evidence],
      ["Insights", s.counts.insights]
    ];
    for (const [label, value] of statDefs) {
      stats.append(
        el("div", { class: "stat" }, [
          el("span", { class: "value" }, [String(value)]),
          el("span", { class: "label" }, [label])
        ])
      );
    }
    root.append(stats);
    if (s.sitesVisited.length > 0) {
      root.append(
        el("div", { class: "current-page" }, [
          `SITES VISITED (${s.sitesVisited.length})`,
          el("strong", {}, [s.sitesVisited.join(", ")])
        ])
      );
    }
    if (s.lastError) {
      root.append(el("p", { class: "error-text" }, [s.lastError]));
    }
    root.append(renderCsat());
    const analyzeBtn = el("button", { class: "primary" }, ["Generate AI Report"]);
    analyzeBtn.addEventListener("click", async () => {
      analyzeBtn.setAttribute("disabled", "true");
      analyzeBtn.textContent = "Generating\u2026";
      const result = await send({ kind: "ANALYZE_SESSION" });
      if (result.error) {
        showToast(result.error, true);
        analyzeBtn.removeAttribute("disabled");
        analyzeBtn.textContent = "Generate AI Report";
        return;
      }
      showToast("Report generated \u2014 opening dashboard");
      if (s.session) window.open(`${API_BASE}/sessions/${s.session.id}?tab=report`, "_blank");
    });
    root.append(analyzeBtn);
    if (s.session) {
      const dashboardBtn = el("button", {}, ["Open in Dashboard"]);
      dashboardBtn.addEventListener("click", () => {
        window.open(`${API_BASE}/sessions/${s.session.id}`, "_blank");
      });
      root.append(dashboardBtn);
    }
    const newSessionBtn = el("button", {}, ["Start New Research"]);
    newSessionBtn.addEventListener("click", () => {
      showStartForm = true;
      render();
    });
    root.append(newSessionBtn);
  }
  function renderSignIn() {
    root.innerHTML = "";
    root.append(el("h2", {}, ["Sign in to ReconLens"]));
    root.append(
      el("p", { class: "subtitle" }, ["Sign in on the ReconLens website, then this panel connects automatically."])
    );
    const signInBtn = el("button", { class: "primary" }, ["Sign in"]);
    signInBtn.addEventListener("click", () => {
      window.open(`${API_BASE}/extension-auth`, "_blank");
    });
    root.append(signInBtn);
  }
  function renderAccountBar() {
    if (!auth?.signedIn) return;
    const signOutBtn = el("button", { class: "link" }, ["Sign out"]);
    signOutBtn.addEventListener("click", async () => {
      await send({ kind: "SIGN_OUT" });
    });
    root.append(el("p", { class: "subtitle" }, [auth.email ?? "Signed in", " \xB7 ", signOutBtn]));
  }
  function render() {
    window.clearInterval(timerInterval);
    recordingBadge.classList.toggle("hidden", state?.status !== "recording");
    pausedBadge.classList.toggle("hidden", state?.status !== "paused");
    const midSession = state?.status === "recording" || state?.status === "paused" || state?.status === "processing";
    if (auth && !auth.signedIn && !midSession) {
      renderSignIn();
      return;
    }
    if (!state || state.status === "idle" || state.status === "completed" && showStartForm) {
      void renderNotStarted().then(renderAccountBar);
      return;
    }
    if (state.status === "recording" || state.status === "paused") {
      renderRecording(state);
      return;
    }
    if (state.status === "processing") {
      renderProcessing();
      return;
    }
    if (state.status === "completed") {
      renderCompleted(state);
      return;
    }
  }
  refreshState();
})();
