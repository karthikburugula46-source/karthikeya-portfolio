"use strict";
(() => {
  // src/content/auth-bridge.ts
  window.addEventListener("message", (event) => {
    if (event.source !== window || event.origin !== window.location.origin) return;
    const data = event.data;
    if (data?.source !== "reconlens-web" || data?.type !== "AUTH_TOKENS") return;
    if (typeof data.accessToken !== "string" || typeof data.refreshToken !== "string") return;
    chrome.runtime.sendMessage({
      kind: "AUTH_TOKENS",
      accessToken: data.accessToken,
      refreshToken: data.refreshToken,
      expiresAt: typeof data.expiresAt === "number" ? data.expiresAt : null,
      email: typeof data.email === "string" ? data.email : null
    }).then((response) => {
      if (response?.ok) {
        window.postMessage({ source: "reconlens-extension", type: "AUTH_ACK" }, window.location.origin);
      }
    }).catch(() => {
    });
  });
})();
