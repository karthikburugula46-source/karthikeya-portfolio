RECONLENS — HOW TO INSTALL (step by step)
=========================================

What is it?
ReconLens is a small add-on for the Google Chrome browser. While you look at
other companies' websites, it takes notes for you and then writes a report
comparing them.

You need: a computer (Mac or Windows) with the Google Chrome browser.
(It does not work on phones.)

This is a test version, so you install it by hand. It is easy — just follow
the steps in order. It takes about 3 minutes.


PART 1 — GET THE FOLDER READY
-----------------------------
1. Find the file called  ReconLens-extension.zip  (it is usually in your
   "Downloads" folder).

2. Double-click it.
   - On a Mac, a new folder called "reconlens-extension" appears next to it.
   - On Windows: right-click the file, click "Extract All...", then click
     "Extract".

3. Move the folder "reconlens-extension" to a place you will remember, like
   your "Documents" folder.
   IMPORTANT: Do not delete or move this folder later. If you do, the add-on
   stops working.


PART 2 — GIVE THE FOLDER TO CHROME
----------------------------------
4. Open the Google Chrome browser.

5. Click the long bar at the very top (the one where you type website names).

6. Type this exactly, then press the Enter key:

        chrome://extensions

   (You can copy it from here and paste it.)

7. Look at the top-right corner of the page. Find the switch that says
   "Developer mode". Click it so it turns ON (it turns blue).
   Three new buttons appear on the left.

8. Click the button called  "Load unpacked".

9. A window opens. Find the folder "reconlens-extension", click it ONE time
   to select it, then click the button at the bottom
   ("Select" on a Mac, "Select Folder" on Windows).

10. A box called "ReconLens" now shows on the page. It is installed!


PART 3 — PUT IT WHERE YOU CAN SEE IT
------------------------------------
11. Look at the top-right of Chrome, next to the long bar. Click the little
    puzzle-piece picture.

12. Find "ReconLens" in the list and click the little pin picture next to it.
    Now the ReconLens button stays on your toolbar.


PART 4 — SIGN IN (only needed once)
-----------------------------------
13. Click the ReconLens button on your toolbar. A panel opens on the right
    side of the screen.

14. Click the button  "Sign in".
    A new tab opens with the ReconLens website.

15. Sign in on that website: type your email and click "Email me a sign-in
    link". Then open your email and click the link inside. Open it in this
    same Chrome browser. (If the email takes a few minutes, please wait.
    Look in "Spam" too. Please do not use the Google button; it is not set
    up yet.)

16. When the page says "Extension connected", you are done. You can close
    that tab.


PART 5 — TRY IT
---------------
17. Click the ReconLens button on your toolbar to open the panel.
18. Pick a project, or click "+ New project" and type any name.
19. Open the website of a company you want to study (for example swiggy.com),
    in another tab.
20. Go back to the ReconLens panel and click  "Start Research".
21. Look around the website like you normally would. If you open a different
    company's website (for example zomato.com), ReconLens notices by itself.
22. Want to keep something? Use the panel's buttons to save text or a
    screenshot.
23. When you are finished, click  "End Research".
24. Click  "Generate AI Report". Wait a little. Your report opens in a new
    tab. Please tell us how it was when it asks!


IF SOMETHING GOES WRONG
-----------------------
* The sign-in page says "Extension not detected":
    1. Go to  chrome://extensions  again.
    2. Find the ReconLens box and click the round arrow (the "reload" button).
    3. Go back to the sign-in tab and refresh it (press Ctrl+R on Windows or
       Cmd+R on a Mac).

* Chrome shows a message like "Disable developer mode extensions" when it
  opens:
    This is normal! It only appears because this is a test version.
    Click "Cancel" or "Keep". Nothing is wrong.

* The ReconLens button is gone after you restarted Chrome:
    Go to  chrome://extensions  and click the switch on the ReconLens box so
    it turns ON again.

* You moved or deleted the folder:
    Do Part 2 again with the folder in its new place.

* To remove ReconLens: go to  chrome://extensions , find the ReconLens box and
  click "Remove".


GOOD TO KNOW
------------
* ReconLens only watches the pages you open AFTER you click "Start Research"
  and BEFORE you click "End Research" (and not while paused).
* It never saves what you type into boxes, like passwords or card numbers.
* This is a free demo: each account can make up to 10 reports per hour, and
  sign-in emails can be slow when many people try at once. If a report says it
  could not be generated, the free AI daily limit may be used up. Try again
  later or tomorrow.
* Works in Chrome version 116 or newer. It also works in Edge, Brave and Arc.
